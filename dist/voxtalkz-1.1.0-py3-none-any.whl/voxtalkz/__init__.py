# __init__.py

from voxtalkz import *

# Version of the voxtalkz package
__version__ = "1.1.0"
